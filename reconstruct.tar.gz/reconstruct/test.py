import shell
import util


# ucs = util.UniformCostSearch(verbose=2)
# ucs.solve(util.NumberLineSearchProblem())

# ucs = util.UniformCostSearch(verbose=2)
# ucs.solve(util.GridSearchProblem(6, 3, 5))

str = "hello"
testStr = "thisisnotmybeautifulhouse"
print(str[1:2])